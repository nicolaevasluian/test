

public class TriangleType {
	public String triangleType(int a, int b, int c) {
		if (a <= 0 || b <= 0 || c <= 0) {
			return "Triangle cannot be formed";
		}
		if (a == b && b == c) {
			return "Equilateral";
		}
		if (b == c || a == b || c == a) {
			return "Isosceles";
		}
		if (a >= b + c || c >= b + a || b >= a + c) {
			return "Triangle cannot be formed";
		}
		return "Scalene";
	}
}
